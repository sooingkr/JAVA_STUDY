package ControllerFolderPractice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BoardListHandler implements ControllHandler{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) {
		
		return null;
	}

}
