package joinService;

public class DuplicatedException extends RuntimeException{

}
