package practicefolder;

import java.io.*;

public class dd {
	public static void main(String[] args) throws FileNotFoundException {
		FileInputStream f = new FileInputStream("a.txt");
		
	}
}
