package _19_FileIO;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.channels.FileChannel;

/**
 * Buffer 瑜??ъ슜?섏뿬 ?깅뒫???μ긽?쒗궎??蹂댁“?ㅽ듃由?
 * BufferedInputStream
 * BufferedOutputStream	: 踰꾪띁 8192媛?Byte [8192]
 * BufferedReader
 * BufferedWriter	: 踰꾪띁 8192媛?Char[8192]
 */
public class _14_FileClass {
	public static void main(String[] args) throws Exception {
	
	} // end of main
} // end of class

