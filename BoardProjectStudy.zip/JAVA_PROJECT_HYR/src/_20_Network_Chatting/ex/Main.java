package _20_Network_Chatting.ex;
public class Main {

   public static void main(String[] args) {

      Client client = new Client();
      client.setVisible(true);

   }

}