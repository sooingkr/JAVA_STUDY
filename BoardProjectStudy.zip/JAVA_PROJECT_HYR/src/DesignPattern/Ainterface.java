package DesignPattern;

public interface Ainterface {
	//  인터페이스 이용한 기능의 선언.
	public void funcA();
}
