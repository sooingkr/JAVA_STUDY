package _10_package_import;

public class PackageClassTemp {
	String name;

	public PackageClassTemp(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.name;
	}
}
