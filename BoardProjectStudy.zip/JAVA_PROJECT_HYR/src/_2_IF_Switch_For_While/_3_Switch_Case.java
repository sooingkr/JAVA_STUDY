package _2_IF_Switch_For_While;

public class _3_Switch_Case {

	public static void main(String[] args) {
		
		int num = 2;
		
		switch( num ){
		case 1 :
			System.out.println(1);
			break;
		case 2:
			System.out.println(2);
			break;
		case 3:
			System.out.println(3);
			break;
		default:
			System.out.println("같은 것이 없음");
			break;
		}
		
		
		
		
//		num = 8;
//		
//		switch( num ){
//		case 10:		
//		case 9:
//			System.out.println("수");
//			break;
//		case 8:
//		case 7:
//			System.out.println("우");
//			break;
//		case 6:
//			System.out.println("미");
//			break;
//		default:
//			System.out.println("가");
//			break;
//		}
		

	}

}
