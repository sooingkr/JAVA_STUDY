package _2_IF_Switch_For_While;

import java.util.Scanner;

public class upperAlpha {

	public static void main(String[] args) {
		
//		char c = 'x';
//		
//		if( c >= 'a' && c<= 'z'){
//			System.out.println(c + "를 대문자로 바꿔서 : " + (char)(c-('a'-'A')) );
//		}else if( c >= 'A' && c <= 'Z'){
//			System.out.println(c + "를 소문자로 바꿔서 : " + (char)(c+('a'-'A')) );
//		}else{
//			System.out.println("대소문자가 아닙니다.");
//		}
//		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		// 사용자 입력 받아 3의 배수이고 5의 배수가 아니면 '3의배수이다' 출력
//		//3의 배수이고 5의 배수이면 '6의 배수이다' 출력
//		System.out.println("판별할 값을 입력하세요 : ");
//		Scanner sc = new Scanner(System.in);
//		int num = sc.nextInt();
//		
//		if(num%6 == 0){
//			System.out.println("6의 배수");
//		}else if(num%3==0){
//			System.out.println("3의 배수");
//		}
//		
//		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	} // end of main

} // end of class
