/**
 * 	[	열거형	Enumeration		]
 */
package _7_Class;

public enum _18_Enumeration {//SUNDAY=0 ~ SATURDAY=5
	SUNDAY,MONDAY,TUESDAY,THURSDAY,FRIDAY,SATURDAY;
}
