package com.example.showmethemajak;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends Activity {

	Button b;
	RadioGroup radiogroup;
	RadioButton r1;
	RadioButton r2;
	int num = 0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		b = (Button)findViewById(R.id.button1);
		r1 = (RadioButton)findViewById(R.id.radio0);
		r2 = (RadioButton)findViewById(R.id.radio1);
		b.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if ( r1.isChecked() ){
					num = Integer.parseInt((String) r1.getTag());
				}
				if ( r2.isChecked() ){
					num = Integer.parseInt((String) r2.getTag());
				}
			}
		}); // end of click
		
		Intent intent = new Intent(this, GameStart.class);
		intent.putExtra("num", num);
		startActivity(intent);
	}
	
}
