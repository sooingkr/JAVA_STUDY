package com.example.showmethemajak;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class GameStart extends Activity {

	TextView tv;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game_start);

		Intent intent = new Intent(this.getIntent());
		int num = Integer.parseInt(intent.getStringExtra("num"));
		
		tv = (TextView)findViewById(R.id.testTextView);
		
		tv.setText(num +"");
	}


}
